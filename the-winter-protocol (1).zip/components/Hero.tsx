import React, { useState, useEffect } from 'react';
import { ArrowDown, Snowflake, Timer } from 'lucide-react';

const Hero: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0 });

  useEffect(() => {
    // Target date: Jan 31, 2025
    const targetDate = new Date('2025-01-31T23:59:59').getTime();
    
    const interval = setInterval(() => {
      const now = new Date().getTime();
      const distance = targetDate - now;
      
      if (distance < 0) {
        clearInterval(interval);
        return;
      }

      setTimeLeft({
        days: Math.floor(distance / (1000 * 60 * 60 * 24)),
        hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const scrollToContent = () => {
    const element = document.getElementById('blueprint');
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="relative h-screen w-full flex flex-col items-center justify-center overflow-hidden bg-slate-950">
      {/* Abstract Tech Grid Background */}
      <div className="absolute inset-0 z-0 opacity-20" 
           style={{
             backgroundImage: 'linear-gradient(#1e293b 1px, transparent 1px), linear-gradient(90deg, #1e293b 1px, transparent 1px)',
             backgroundSize: '40px 40px'
           }} 
      />
      <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-slate-950 via-transparent to-slate-950 z-0" />
      
      {/* Glowing Orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-900/20 rounded-full blur-[100px] animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-indigo-900/20 rounded-full blur-[100px]" />

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-5xl mx-auto flex flex-col items-center">
        
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-cyan-500/20 bg-cyan-950/30 text-cyan-400 font-mono text-sm mb-8 animate-fade-in">
          <div className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
          SYSTEM ONLINE: WINTER_PROTOCOL
        </div>

        <h1 className="text-6xl md:text-8xl font-bold tracking-tighter text-white mb-6 uppercase">
          The Winter <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-indigo-500">Protocol</span>
        </h1>
        
        <p className="text-lg md:text-xl text-slate-400 max-w-2xl mx-auto mb-10 leading-relaxed font-light">
          We don't do "arcs" here. This is a <span className="text-white font-medium">calculated operation</span>.
          Optimize your mind, build undeniable consistency, and execute high-value leisure. 
        </p>

        {/* Countdown Stats */}
        <div className="flex gap-8 mb-12">
            <div className="text-center">
                <div className="text-4xl font-mono font-bold text-white">{timeLeft.days}</div>
                <div className="text-xs uppercase tracking-widest text-slate-500">Days Left</div>
            </div>
            <div className="h-12 w-px bg-slate-800"></div>
            <div className="text-center">
                <div className="text-4xl font-mono font-bold text-white">{timeLeft.hours}</div>
                <div className="text-xs uppercase tracking-widest text-slate-500">Hours Left</div>
            </div>
        </div>

        <button 
          onClick={scrollToContent}
          className="group relative px-8 py-4 bg-white text-slate-950 font-bold rounded-lg overflow-hidden transition-all hover:scale-105"
        >
          <div className="absolute inset-0 w-full h-full bg-cyan-400 opacity-0 group-hover:opacity-100 transition-opacity blur-xl" />
          <span className="relative flex items-center gap-2">
            Initiate Protocol <ArrowDown className="w-4 h-4" />
          </span>
        </button>
      </div>
    </div>
  );
};

export default Hero;