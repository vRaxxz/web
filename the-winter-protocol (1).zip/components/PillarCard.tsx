import React from 'react';
import { LucideIcon } from 'lucide-react';

interface PillarCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  colorClass: string;
  items: string[];
}

const PillarCard: React.FC<PillarCardProps> = ({ title, description, icon: Icon, colorClass, items }) => {
  return (
    <div className="glass-panel rounded-xl p-8 transition-all duration-300 hover:bg-slate-900/80 border border-slate-800 hover:border-slate-600 group">
      <div className={`w-12 h-12 rounded-lg ${colorClass} bg-opacity-10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
        <Icon className={`w-6 h-6 ${colorClass.replace('bg-', 'text-').replace('/20', '')}`} />
      </div>
      
      <h3 className="text-lg font-bold text-white mb-2 font-mono uppercase tracking-wide">{title}</h3>
      <p className="text-slate-500 mb-6 text-sm leading-relaxed min-h-[40px]">{description}</p>
      
      <div className="space-y-4">
        {items.map((item, index) => (
          <div key={index} className="flex items-start gap-3">
            <div className="mt-1.5 w-1 h-1 rounded-full bg-slate-600 group-hover:bg-slate-400 transition-colors" />
            <span className="text-slate-400 text-sm group-hover:text-slate-200 transition-colors">{item}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PillarCard;