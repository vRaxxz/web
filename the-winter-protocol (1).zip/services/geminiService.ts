import { GoogleGenAI, Type } from "@google/genai";
import { AICoachResponse, SideQuestResponse } from "../types";

// Initialize the Gemini API client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const MODEL_NAME = 'gemini-2.5-flash';

export const getDailyGuidance = async (mood: string, focus: string): Promise<AICoachResponse> => {
  try {
    const prompt = `
      You are the "Protocol Overseer". A disciplined, strategic, yet encouraging AI mentor.
      The user is following "The Winter Protocol" (Dec-Jan).
      Goals: Self-Improvement, Radical Consistency, and Genuine Fun (not cheap dopamine).
      
      Current State:
      Mood: ${mood}
      Focus: ${focus}
      
      Generate a tactical advice snippet and a concrete objective.
      Style: Minimalist, tech-forward, military-lite, encouraging.
      
      Return JSON.
    `;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            advice: { type: Type.STRING },
            actionItem: { type: Type.STRING },
          },
          required: ["advice", "actionItem"],
        },
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    return JSON.parse(text) as AICoachResponse;

  } catch (error) {
    console.error("Error fetching guidance:", error);
    return {
      advice: "System offline. Rely on your baseline discipline.",
      actionItem: "Manual Override: Review your goals immediately."
    };
  }
};

export const getSideQuest = async (socialLevel: string, budget: string): Promise<SideQuestResponse> => {
  try {
    const prompt = `
      Generate a real-world "Side Quest" for a user who wants to go out and have fun this winter.
      It should be something interesting, not generic.
      
      Constraints:
      Social Level: ${socialLevel} (Solo, With Friends, or Crowd)
      Budget: ${budget}
      Season: Winter (Dec/Jan)
      
      Return JSON with title, description, estimatedCost, and vibe.
    `;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            estimatedCost: { type: Type.STRING },
            vibe: { type: Type.STRING },
          },
          required: ["title", "description", "estimatedCost", "vibe"],
        },
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response");
    return JSON.parse(text) as SideQuestResponse;
  } catch (error) {
    console.error(error);
    return {
      title: "Operation: Walk",
      description: "Go for a 30 minute walk without your phone.",
      estimatedCost: "$0",
      vibe: "Chill"
    };
  }
};
