import React from 'react';
import Hero from './components/Hero';
import PillarCard from './components/PillarCard';
import Timeline from './components/Timeline';
import ProtocolOps from './components/GeminiCoach';
import CommitmentGrid from './components/CommitmentGrid';
import TheVault from './components/TheVault';
import { Cpu, Repeat, Wine } from 'lucide-react';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans selection:bg-cyan-500/30">
      <Hero />
      
      <main id="blueprint" className="container mx-auto px-4 -mt-20 relative z-20 pb-24 space-y-24">
        
        {/* Section 1: Core Pillars */}
        <section>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <PillarCard 
                title="Optimization"
                description="Aggressive upskilling. Expanding the cognitive toolkit."
                icon={Cpu}
                colorClass="bg-cyan-500"
                items={[
                "Advanced React & AI Integration",
                "Read: 1 Tech / 1 Fiction",
                "Hypertrophy Training (4x/wk)",
                "Language Acquisition: Spanish"
                ]}
            />
            <PillarCard 
                title="Consistency"
                description="The algorithmic approach to daily habits."
                icon={Repeat}
                colorClass="bg-indigo-500"
                items={[
                "0800 Wake Up Protocol",
                "First 60m: Deep Work (No Phone)",
                "Data Logging (Journal)",
                "Sunday System Review"
                ]}
            />
            <PillarCard 
                title="Vitality"
                description="Real world engagement. High-quality dopamine only."
                icon={Wine}
                colorClass="bg-emerald-500"
                items={[
                "Winter Markets Exploration",
                "Weekly Squad Dinners",
                "Slope Operations (Skiing)",
                "Analog Nights (No Screens)"
                ]}
            />
            </div>
        </section>

        {/* Section 2: Command Center (Coach + Grid) */}
        <section className="grid grid-cols-1 xl:grid-cols-3 gap-8">
            <div className="xl:col-span-2">
                <CommitmentGrid />
            </div>
            <div className="xl:col-span-1">
                <TheVault />
            </div>
        </section>

        {/* Section 3: AI Operations */}
        <section>
           <ProtocolOps />
        </section>

        {/* Section 4: Timeline */}
        <section>
            <Timeline />
        </section>

      </main>

      <footer className="border-t border-slate-900 bg-slate-950 py-12 text-center">
        <p className="text-slate-600 text-sm font-mono">
          THE WINTER PROTOCOL • STATUS: ACTIVE
        </p>
      </footer>
    </div>
  );
};

export default App;