export enum GoalCategory {
  IMPROVEMENT = 'IMPROVEMENT',
  CONSISTENCY = 'CONSISTENCY',
  FUN = 'FUN'
}

export interface DailyTask {
  id: string;
  title: string;
  category: GoalCategory;
  completed: boolean;
}

export interface AICoachResponse {
  advice: string;
  actionItem: string;
}

export interface SideQuestResponse {
  title: string;
  description: string;
  estimatedCost: string;
  vibe: string;
}
