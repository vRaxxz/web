import React from 'react';
import { CalendarDays, Rocket, Target, Crown } from 'lucide-react';

const phases = [
  {
    date: 'Phase 1: Foundation',
    sub: 'Dec 1 - Dec 15',
    desc: 'System reset. Sleep calibration. Environment optimization.',
    icon: Rocket,
    color: 'text-cyan-400',
    bg: 'bg-cyan-400'
  },
  {
    date: 'Phase 2: Deep Ops',
    sub: 'Dec 16 - Dec 31',
    desc: 'Maximum output in AM. Strategic leisure in PM. No burnout.',
    icon: CalendarDays,
    color: 'text-indigo-400',
    bg: 'bg-indigo-400'
  },
  {
    date: 'Phase 3: The Ascent',
    sub: 'Jan 1 - Jan 15',
    desc: 'Acceleration. Testing new skills in the wild. High intensity.',
    icon: Target,
    color: 'text-emerald-400',
    bg: 'bg-emerald-400'
  },
  {
    date: 'Phase 4: Integration',
    sub: 'Jan 15+',
    desc: 'Protocol complete. New baseline established. Deployment.',
    icon: Crown,
    color: 'text-amber-400',
    bg: 'bg-amber-400'
  }
];

const Timeline: React.FC = () => {
  return (
    <div className="py-20 px-4">
      <h2 className="text-3xl font-bold text-center text-white mb-20 font-mono uppercase tracking-widest">
        <span className="text-slate-600">///</span> Temporal Map
      </h2>
      <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6 relative">
        
        {phases.map((phase, idx) => (
          <div key={idx} className="glass-panel p-8 rounded-xl relative overflow-hidden group hover:border-slate-600 transition-colors">
            
            <div className={`absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity`}>
                 <phase.icon className={`w-24 h-24 ${phase.color}`} />
            </div>

            <div className="relative z-10">
                <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full ${phase.bg} bg-opacity-10 border border-${phase.color}/20 mb-4`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${phase.bg}`}></span>
                    <span className={`text-xs font-mono font-bold ${phase.color}`}>{phase.sub}</span>
                </div>
                
                <h3 className="text-xl font-bold text-white mb-2">{phase.date}</h3>
                <p className="text-slate-400 text-sm leading-relaxed max-w-[85%]">{phase.desc}</p>
            </div>
            
            <div className={`absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-${phase.color.replace('text-', '')} to-transparent opacity-0 group-hover:opacity-50 transition-opacity`} />
          </div>
        ))}
      </div>
    </div>
  );
};

export default Timeline;