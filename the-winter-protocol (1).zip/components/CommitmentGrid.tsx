import React, { useState } from 'react';
import { Trophy, CheckCircle2 } from 'lucide-react';

const CommitmentGrid: React.FC = () => {
  // Generate a mock grid for Dec 1 to Jan 31 (62 days)
  const [completedDays, setCompletedDays] = useState<number[]>([1, 2, 3, 5, 6, 8, 9, 12, 13, 14, 15]); // Mock data

  const toggleDay = (dayIndex: number) => {
    if (completedDays.includes(dayIndex)) {
      setCompletedDays(completedDays.filter(d => d !== dayIndex));
    } else {
      setCompletedDays([...completedDays, dayIndex]);
    }
  };

  const days = Array.from({ length: 62 }, (_, i) => i + 1);

  return (
    <div className="glass-panel p-8 rounded-2xl border border-slate-800">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white font-mono flex items-center gap-3">
            <CheckCircle2 className="text-emerald-500" />
            Consistency Visualizer
          </h2>
          <p className="text-slate-400 text-sm mt-1">
            Visual proof of your momentum. Don't break the chain.
          </p>
        </div>
        <div className="bg-slate-900/50 px-4 py-2 rounded-lg border border-slate-800 flex items-center gap-2">
          <Trophy className="w-4 h-4 text-yellow-500" />
          <span className="text-slate-200 font-mono font-bold">{completedDays.length} / 62 Days</span>
        </div>
      </div>

      {/* The Grid */}
      <div className="grid grid-cols-7 sm:grid-cols-10 md:grid-cols-[repeat(auto-fit,minmax(2rem,1fr))] gap-2">
        {days.map((day) => {
           const isCompleted = completedDays.includes(day);
           // Calculate opacity for a "fading" trail effect or just binary
           const bgClass = isCompleted ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.4)]' : 'bg-slate-800 hover:bg-slate-700';
           
           return (
             <button
               key={day}
               onClick={() => toggleDay(day)}
               className={`
                 aspect-square rounded-sm sm:rounded-md transition-all duration-300 relative group
                 ${bgClass}
               `}
               title={`Day ${day}`}
             >
                <span className={`absolute inset-0 flex items-center justify-center text-[10px] font-mono ${isCompleted ? 'text-emerald-950 font-bold' : 'text-slate-600'}`}>
                    {day}
                </span>
             </button>
           );
        })}
      </div>
      
      <div className="mt-6 flex items-center gap-4 text-xs text-slate-500 font-mono">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-slate-800 rounded-sm"></div>
          <span>Pending</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-emerald-500 rounded-sm"></div>
          <span>Executed</span>
        </div>
      </div>
    </div>
  );
};

export default CommitmentGrid;