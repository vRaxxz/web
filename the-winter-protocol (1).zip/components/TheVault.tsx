import React, { useState } from 'react';
import { BookOpen, Gamepad2, MonitorPlay, ChevronDown } from 'lucide-react';

type Section = 'INTEL' | 'LEISURE' | 'SKILLS';

const TheVault: React.FC = () => {
  const [activeSection, setActiveSection] = useState<Section>('INTEL');

  const content = {
    INTEL: [
      { title: "Atomic Habits", author: "James Clear", status: "Reading", type: "Book" },
      { title: "Deep Work", author: "Cal Newport", status: "Queue", type: "Book" },
      { title: "Meditations", author: "Marcus Aurelius", status: "Done", type: "Book" },
    ],
    LEISURE: [
      { title: "Hades II", author: "Supergiant", status: "Playing", type: "Game" },
      { title: "Arcane Season 2", author: "Netflix", status: "Watching", type: "Show" },
      { title: "Local Winter Market", author: "City Center", status: "Plan", type: "Event" },
    ],
    SKILLS: [
      { title: "Advanced React Patterns", author: "Frontend Masters", status: "In Progress", type: "Course" },
      { title: "Spanish A2 Vocabulary", author: "Duolingo", status: "Daily", type: "Language" },
    ]
  };

  const renderIcon = (section: Section) => {
    switch(section) {
        case 'INTEL': return <BookOpen className="w-4 h-4" />;
        case 'LEISURE': return <Gamepad2 className="w-4 h-4" />;
        case 'SKILLS': return <MonitorPlay className="w-4 h-4" />;
    }
  };

  return (
    <div className="glass-panel rounded-2xl overflow-hidden border border-slate-800">
        <div className="p-6 border-b border-slate-800 bg-slate-900/50">
            <h2 className="text-xl font-bold text-white font-mono">The Vault</h2>
            <p className="text-slate-400 text-sm">Resource allocation and entertainment log.</p>
        </div>
        
        <div className="flex border-b border-slate-800">
            {(['INTEL', 'SKILLS', 'LEISURE'] as Section[]).map((sec) => (
                <button
                    key={sec}
                    onClick={() => setActiveSection(sec)}
                    className={`flex-1 py-4 text-sm font-mono font-bold flex items-center justify-center gap-2 transition-colors ${
                        activeSection === sec 
                        ? 'bg-slate-800/50 text-cyan-400 border-b-2 border-cyan-400' 
                        : 'text-slate-500 hover:text-slate-300'
                    }`}
                >
                    {renderIcon(sec)}
                    {sec}
                </button>
            ))}
        </div>

        <div className="p-6">
            <div className="space-y-4">
                {content[activeSection].map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between p-4 bg-slate-900/40 rounded-lg border border-slate-800/50 hover:border-slate-700 transition-colors">
                        <div>
                            <h3 className="text-white font-medium">{item.title}</h3>
                            <p className="text-slate-500 text-xs mt-1">{item.author}</p>
                        </div>
                        <div className="flex items-center gap-3">
                            <span className="text-xs font-mono text-slate-500 uppercase">{item.type}</span>
                            <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wide
                                ${item.status === 'Done' ? 'bg-emerald-900/30 text-emerald-400' : 
                                  item.status === 'Playing' || item.status === 'Reading' || item.status === 'In Progress' ? 'bg-cyan-900/30 text-cyan-400' :
                                  'bg-slate-800 text-slate-400'
                                }
                            `}>
                                {item.status}
                            </span>
                        </div>
                    </div>
                ))}
            </div>
            <button className="w-full mt-6 py-3 border border-dashed border-slate-700 rounded-lg text-slate-500 text-sm hover:bg-slate-800/50 hover:text-white transition-colors flex items-center justify-center gap-2">
                + Add Resource
            </button>
        </div>
    </div>
  );
};

export default TheVault;