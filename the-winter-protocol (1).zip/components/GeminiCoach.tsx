import React, { useState } from 'react';
import { Sparkles, Loader2, Target, Map, Users, User, Zap } from 'lucide-react';
import { getDailyGuidance, getSideQuest } from '../services/geminiService';
import { AICoachResponse, SideQuestResponse } from '../types';

type Mode = 'GUIDANCE' | 'QUEST';

const ProtocolOps: React.FC = () => {
  const [mode, setMode] = useState<Mode>('GUIDANCE');
  
  // Guidance State
  const [mood, setMood] = useState<string>('Focused');
  const [focus, setFocus] = useState<string>('Improvement');
  const [guidanceData, setGuidanceData] = useState<AICoachResponse | null>(null);

  // Quest State
  const [socialLevel, setSocialLevel] = useState<string>('Solo');
  const [budget, setBudget] = useState<string>('Low Cost');
  const [questData, setQuestData] = useState<SideQuestResponse | null>(null);

  const [loading, setLoading] = useState<boolean>(false);

  const handleGenerate = async () => {
    setLoading(true);
    try {
        if (mode === 'GUIDANCE') {
            const res = await getDailyGuidance(mood, focus);
            setGuidanceData(res);
        } else {
            const res = await getSideQuest(socialLevel, budget);
            setQuestData(res);
        }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto my-20">
        <div className="glass-panel rounded-3xl overflow-hidden neon-border">
            
            {/* Header Tabs */}
            <div className="flex border-b border-slate-800">
                <button 
                    onClick={() => setMode('GUIDANCE')}
                    className={`flex-1 py-5 text-center font-mono font-bold uppercase tracking-wider transition-colors flex items-center justify-center gap-2 ${mode === 'GUIDANCE' ? 'bg-indigo-600/20 text-indigo-300' : 'text-slate-500 hover:text-slate-300'}`}
                >
                    <Target className="w-4 h-4" /> Tactical Briefing
                </button>
                <button 
                    onClick={() => setMode('QUEST')}
                    className={`flex-1 py-5 text-center font-mono font-bold uppercase tracking-wider transition-colors flex items-center justify-center gap-2 ${mode === 'QUEST' ? 'bg-cyan-600/20 text-cyan-300' : 'text-slate-500 hover:text-slate-300'}`}
                >
                    <Map className="w-4 h-4" /> Side Quest Gen
                </button>
            </div>
            
            <div className="p-6 md:p-10 flex flex-col md:flex-row gap-10">
                
                {/* Controls Area */}
                <div className="flex-1 space-y-8">
                    <div>
                        <h2 className="text-2xl font-bold text-white mb-2">
                            {mode === 'GUIDANCE' ? 'Daily Directives' : 'Adventure Protocol'}
                        </h2>
                        <p className="text-slate-400 text-sm">
                            {mode === 'GUIDANCE' 
                             ? 'Get a tactical plan for today based on your current psychometrics.' 
                             : 'Break the monotony. Generate a mission to touch grass and engage with reality.'}
                        </p>
                    </div>

                    <div className="space-y-6">
                        {mode === 'GUIDANCE' ? (
                            <>
                                <div className="space-y-3">
                                    <label className="text-xs font-mono text-slate-500 uppercase">Status Report (Mood)</label>
                                    <div className="flex flex-wrap gap-2">
                                        {['Focused', 'Drained', 'Restless', 'Stoic'].map((m) => (
                                            <button key={m} onClick={() => setMood(m)} className={`px-4 py-2 rounded-lg text-sm border ${mood === m ? 'bg-indigo-500 text-white border-indigo-500' : 'border-slate-700 text-slate-400 hover:border-slate-500'}`}>{m}</button>
                                        ))}
                                    </div>
                                </div>
                                <div className="space-y-3">
                                    <label className="text-xs font-mono text-slate-500 uppercase">Objective Focus</label>
                                    <div className="flex flex-wrap gap-2">
                                        {['Improvement', 'Consistency', 'Maintenance'].map((f) => (
                                            <button key={f} onClick={() => setFocus(f)} className={`px-4 py-2 rounded-lg text-sm border ${focus === f ? 'bg-indigo-500 text-white border-indigo-500' : 'border-slate-700 text-slate-400 hover:border-slate-500'}`}>{f}</button>
                                        ))}
                                    </div>
                                </div>
                            </>
                        ) : (
                            <>
                                <div className="space-y-3">
                                    <label className="text-xs font-mono text-slate-500 uppercase">Squad Size</label>
                                    <div className="flex gap-2">
                                        <button onClick={() => setSocialLevel('Solo')} className={`flex-1 py-3 rounded-lg border flex items-center justify-center gap-2 ${socialLevel === 'Solo' ? 'bg-cyan-500/20 text-cyan-400 border-cyan-500' : 'border-slate-700 text-slate-400'}`}>
                                            <User className="w-4 h-4" /> Solo
                                        </button>
                                        <button onClick={() => setSocialLevel('Friends')} className={`flex-1 py-3 rounded-lg border flex items-center justify-center gap-2 ${socialLevel === 'Friends' ? 'bg-cyan-500/20 text-cyan-400 border-cyan-500' : 'border-slate-700 text-slate-400'}`}>
                                            <Users className="w-4 h-4" /> Squad
                                        </button>
                                    </div>
                                </div>
                                <div className="space-y-3">
                                    <label className="text-xs font-mono text-slate-500 uppercase">Resource Allocation</label>
                                    <div className="flex gap-2">
                                        {['Free', 'Low Cost', 'Treat Yourself'].map((b) => (
                                            <button key={b} onClick={() => setBudget(b)} className={`flex-1 py-2 text-xs rounded-lg border ${budget === b ? 'bg-cyan-500/20 text-cyan-400 border-cyan-500' : 'border-slate-700 text-slate-400'}`}>
                                                {b}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            </>
                        )}

                        <button
                            onClick={handleGenerate}
                            disabled={loading}
                            className={`w-full py-4 font-bold rounded-lg transition-all shadow-lg flex items-center justify-center gap-2 
                                ${mode === 'GUIDANCE' 
                                    ? 'bg-indigo-600 hover:bg-indigo-500 shadow-indigo-500/20' 
                                    : 'bg-cyan-600 hover:bg-cyan-500 shadow-cyan-500/20'}`}
                        >
                            {loading ? <Loader2 className="animate-spin w-5 h-5" /> : <Sparkles className="w-5 h-5" />}
                            {loading ? 'Processing...' : (mode === 'GUIDANCE' ? 'Initialize Briefing' : 'Generate Mission')}
                        </button>
                    </div>
                </div>

                {/* Output Area */}
                <div className="w-full md:w-[450px] min-h-[350px] bg-slate-950 rounded-xl border border-slate-800 p-8 flex flex-col relative">
                    {/* Placeholder */}
                    {(!guidanceData && mode === 'GUIDANCE' && !loading) && (
                        <div className="flex-1 flex flex-col items-center justify-center text-slate-700">
                            <Target className="w-16 h-16 mb-4 opacity-20" />
                            <p className="font-mono text-xs uppercase tracking-widest">Awaiting Input</p>
                        </div>
                    )}
                    {(!questData && mode === 'QUEST' && !loading) && (
                         <div className="flex-1 flex flex-col items-center justify-center text-slate-700">
                             <Map className="w-16 h-16 mb-4 opacity-20" />
                             <p className="font-mono text-xs uppercase tracking-widest">Awaiting Parameters</p>
                         </div>
                    )}
                    
                    {/* Loading State */}
                    {loading && (
                        <div className="absolute inset-0 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm z-10">
                            <div className="text-center">
                                <div className={`w-12 h-12 border-4 rounded-full animate-spin mb-4 ${mode === 'GUIDANCE' ? 'border-indigo-500/30 border-t-indigo-500' : 'border-cyan-500/30 border-t-cyan-500'}`}></div>
                                <p className="font-mono text-xs text-slate-400 animate-pulse">
                                    COMMS LINK ESTABLISHED<br/>Retrieving Data...
                                </p>
                            </div>
                        </div>
                    )}

                    {/* Results */}
                    {mode === 'GUIDANCE' && guidanceData && !loading && (
                        <div className="animate-fade-in flex flex-col h-full justify-between">
                            <div>
                                <h3 className="text-indigo-500 font-mono text-xs uppercase tracking-widest mb-4">Briefing Details</h3>
                                <p className="text-xl text-white font-light leading-relaxed mb-6">"{guidanceData.advice}"</p>
                            </div>
                            <div className="bg-slate-900 rounded-lg p-5 border border-slate-800">
                                <div className="flex items-center gap-2 mb-2">
                                    <Zap className="w-4 h-4 text-yellow-400" />
                                    <span className="text-xs font-bold text-slate-400 uppercase">Primary Directive</span>
                                </div>
                                <p className="text-indigo-200 font-medium">{guidanceData.actionItem}</p>
                            </div>
                        </div>
                    )}

                    {mode === 'QUEST' && questData && !loading && (
                         <div className="animate-fade-in flex flex-col h-full">
                            <div className="flex-1">
                                <div className="flex justify-between items-start mb-4">
                                     <h3 className="text-cyan-500 font-mono text-xs uppercase tracking-widest">New Mission Available</h3>
                                     <span className="px-2 py-1 bg-slate-900 rounded text-[10px] text-slate-400 border border-slate-800">{questData.vibe}</span>
                                </div>
                                <h2 className="text-2xl font-bold text-white mb-4 leading-tight">{questData.title}</h2>
                                <p className="text-slate-300 leading-relaxed">{questData.description}</p>
                            </div>
                            
                            <div className="mt-8 pt-6 border-t border-slate-900 grid grid-cols-2 gap-4">
                                <div>
                                    <span className="text-xs text-slate-600 uppercase block mb-1">Cost Est.</span>
                                    <span className="text-white font-mono">{questData.estimatedCost}</span>
                                </div>
                                <div className="text-right">
                                    <button className="text-xs text-cyan-400 hover:text-cyan-300 underline underline-offset-4">
                                        Accept Mission
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}

                </div>
            </div>
        </div>
    </div>
  );
};

export default ProtocolOps;